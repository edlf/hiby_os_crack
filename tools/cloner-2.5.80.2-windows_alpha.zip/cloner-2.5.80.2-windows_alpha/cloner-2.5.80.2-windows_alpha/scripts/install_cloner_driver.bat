
cd /d "%~dp0"

pnputil /add-driver ..\cloner-win32-driver\usb_cloner_device.inf /install

