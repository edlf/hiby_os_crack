#!/usr/bin/python3
import os
import zipfile
import argparse
import configparser
import re

def modifyPlatform(cloner_path, config_path):
    platform_path = f"{cloner_path}/configs/platforms.cfg"
    config_name:str = os.path.basename(config_path)
    config_name_list = config_name.split('_')
    platfrom_name = config_name_list[0]
    if platfrom_name == 'slt':
        platfrom_name = config_name_list[1]
        if platfrom_name == 'master':
            platfrom_name = config_name_list[2]
     
    if (platfrom_name == 'x1501' or
        platfrom_name == 'x1500' or
        platfrom_name == 'x1500l' or
        platfrom_name == 'x1500la'):
        platfrom_name = 'x1500'
    elif (platfrom_name == 'x1600' or
          platfrom_name == 'x1600e' or
          platfrom_name == 'x1600en' or
          platfrom_name == 'x1600hn' or
          platfrom_name == 'x1600mn' or
          platfrom_name == 'x1660' or
          platfrom_name == 'x1660l'):
        platfrom_name = 'x1600'
    elif (platfrom_name == 'x2000' or
          platfrom_name == 'x2000e' or
          platfrom_name == 'x2000h'):
        platfrom_name = 'x2000'
    elif (platfrom_name == 'x2100' or
          platfrom_name == 'x2100l'):
        platfrom_name = 'x2100'
    elif (platfrom_name == 'x2500' or
          platfrom_name == 'x2500a'):
        platfrom_name = 'x2500'
    elif (platfrom_name == 'x2600' or
          platfrom_name == 'x2600e' or
          platfrom_name == 'x2600h' or
          platfrom_name == 'x2600m' or
          platfrom_name == 'x2660' or
          platfrom_name == 'x2670' or
          platfrom_name == 'x2670m'):
        platfrom_name = 'x2600'
        
    # 读取配置文件
    config = configparser.ConfigParser()
    config.optionxform = lambda option: option
    config.read(platform_path, encoding='utf-8')

    if config.has_section('current'):
        config.set('current', 'board', config_name)
        print(f"[current] board={config_name}")
    
    if config.has_section('platforms'):
        options = config.options('platforms')
        # 遍历平台选项
        for opt in options:
            value = config.get('platforms', opt)
            # 匹配与板级名中相同的平台名
            if value == platfrom_name:
                index = re.findall(r'\d+', opt)[0]
                config.set('current', 'platform', f"\"{index},{platfrom_name}\"")
                print(f"[current] platform=\"{index},{platfrom_name}\"")
                break
    
    # 将修改后的配置写回文件
    with open(platform_path, 'w', encoding='utf-8') as config_file:
        config.write(config_file, space_around_delimiters=False)
    

def modifyPolicy(config_path, images, ingenic_file):

    # 读取配置文件
    config = configparser.ConfigParser()
    config.optionxform = lambda option: option
    config.read(config_path, encoding='utf-8')
    
    for i in range(len(images)):
        section = f"policy{i}"
        if len(images[i]) == 0:
            if config.has_section(section):
                config.set(section, 'enabled', '0')
                print(f"[{section}] enabled=0")
            continue
        
        file_name = os.path.basename(images[i])

        # 修改 policy 下的 attribute 值
        for section in config.sections():
            if section.startswith(f"policy{i}"):
                config.set(section, 'enabled', '1')
                print(f"[{section}] enabled=1")
                config.set(section, 'attribute', f"\"{ingenic_file}|{file_name}\"")
                print(f"[{section}] attribute=\"{ingenic_file}|{file_name}\"")

    # 将修改后的配置写回文件
    with open(config_path, 'w', encoding='utf-8') as config_file:
        config.write(config_file, space_around_delimiters=False)
        

def zipDirectory(input_path, output_path, policy_files):
    
    # 将被打包到ingenic文件中的烧录工具下目录
    cloner_folders = ['configs', 'firmwares', 'ddrs', 'securitytool', 'security']

    # 创建一个ZipFile对象，并指定压缩模式为'w'（写）
    with zipfile.ZipFile(output_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
        # 遍历目录中的所有文件和子目录
        for root, dirs, files in os.walk(input_path):
            # 获取当前目录相对于输入路径的相对路径
            relative_root = os.path.relpath(root, input_path)
            
            # 检查当前目录是否在 cloner_folders 中
            if any(relative_root.startswith(folder + os.sep) or relative_root == folder for folder in cloner_folders):
                # 对于每个文件
                for file in files:
                    # 构建完整的文件路径
                    file_path = os.path.join(root, file)
                    # 构建ZIP文件中的相对路径
                    arcname = os.path.relpath(file_path, start=input_path)
                    # 将文件添加到ZIP文件中
                    zipf.write(file_path, arcname)
                    
        for file in policy_files:
            if os.path.isfile(file):
                filename = os.path.basename(file)
                arcname = 'images/' + filename
                zipf.write(file, arcname)

    print(f"ZIP file created at: {output_path}")


def main():
    # 创建解析器
    parser = argparse.ArgumentParser(description=
    ''' 使用实例:
        ./cloner.py -i cloner_path -o ingenic_file -c config_file -p ~/uboot -p ~/kernel -p ~/system.ubi
    ''')

    # 添加参数
    parser.add_argument('-i', '--input',  help='烧录工具所在路径, 指定到configs/和firmwares/同级目录', type=str, required=True)
    parser.add_argument('-o', '--output', help='生成ingenic文件, 指定ingenic文件名称及保存路径', type=str, required=True)
    parser.add_argument('-c', '--config', help='烧录工具配置文件, 指定烧录工具configs/平台/目录下的配置文件', type=str, required=True)
    parser.add_argument('-p', '--policy', help='烧录镜像文件路径, 允许零个或多个"-p"参数', action='append', type=str, required=True)

    # 解析参数
    args = parser.parse_args()
    
    # 打印参数值
    print(f"烧录工具所在路径: {args.input}")
    print(f"生成ingenic文件: {args.output}")
    if args.config:
        print(f"烧录工具配置文件: {args.config}")
    if args.policy:
        for policy in args.policy:
            print(f"烧录镜像文件路径: {policy}")
            
    clonerPath = args.input
    ingenicFile = args.output
    configFile = args.config
    policyFiles = args.policy
    
    # 修改配置文件中镜像路径
    if configFile:
        modifyPlatform(clonerPath, configFile)
        modifyPolicy(configFile, policyFiles, ingenicFile)
    
    # 删除 ingenic 文件
    if os.path.exists(ingenicFile):
        os.remove(ingenicFile)
    
    # 执行打包压缩
    zipDirectory(clonerPath, ingenicFile, policyFiles)
            
            
if __name__ == "__main__":
    main()
    

