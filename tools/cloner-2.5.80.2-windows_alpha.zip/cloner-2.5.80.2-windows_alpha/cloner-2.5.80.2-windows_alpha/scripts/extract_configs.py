#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import shutil
import fnmatch
#import ConfigParser  # Python 2
from configparser import ConfigParser  #  Python 3
import argparse

def set_config_value_to_file(file_path, section, option, new_value):
    """Helper function to read a specific value from a configuration file."""
#    config = ConfigParser.ConfigParser()  # Python 2
    config = ConfigParser()  #  Python 3
    config.optionxform = str

    if not os.path.exists(file_path):
        raise IOError("The configuration file does not exist: {}".format(file_path))

    config.read(file_path)

    config.set(section, option, new_value)

    with open(file_path, 'w') as f:
        config.write(f, space_around_delimiters=False)



def get_config_value_from_file(file_path, section, option):
    """Helper function to read a specific value from a configuration file."""
    #config = ConfigParser.ConfigParser()  # Python 2
    config = ConfigParser()  #  Python 3

    if not os.path.exists(file_path):
        raise IOError("The configuration file does not exist: {}".format(file_path))

    config.read(file_path)

    try:
        value = config.get(section, option)
        return value.strip().replace('"', '').replace("'", '')
    except (ConfigParser.NoSectionError, ConfigParser.NoOptionError) as e:
        print("Error reading configuration: {}".format(e))
        return None

def get_config_values(source_path):
    """Extract multiple configuration values from different config files."""

    platform_cfg_path = os.path.join(source_path, 'configs', 'platforms.cfg')


    platform_value = get_config_value_from_file(platform_cfg_path, 'current', 'platform')
    if platform_value is None or ',' not in platform_value:
        print("Invalid platform value or configuration missing.")
        return None
    platform_name = platform_value.split(',')[1].strip()

    board_cfg = get_config_value_from_file(platform_cfg_path, 'current', 'board')
    if board_cfg is None:
        return None
    board_cfg_path = os.path.join(source_path, 'configs', platform_name, board_cfg)

    ddr_type_value = get_config_value_from_file(board_cfg_path, 'ddr', 'current_type')
    if ddr_type_value is None:
        return None
    ddr_type = ddr_type_value.split(',')[1].strip()

    ddr_cfg = get_config_value_from_file(board_cfg_path, 'ddr', 'current_ddr')
    if ddr_cfg is None:
        return None
    ddr_cfg_path = os.path.join(source_path, 'ddrs', ddr_type, ddr_cfg)

    return {
        'platform_name': platform_name,
	'board_cfg' : board_cfg,
        'board_cfg_path': board_cfg_path,
	'ddr_cfg' : ddr_cfg,
        'ddr_cfg_path': ddr_cfg_path,
	'ddr_type' : ddr_type,
    }

def extract_config_to_factorytool(source_path, target_dir):

    config_values = get_config_values(source_path)

    if config_values is None:
        print("Failed to retrieve configuration values.")
        return

    platform_name = config_values['platform_name']
    board_cfg = config_values['board_cfg']
    board_cfg_path = config_values['board_cfg_path']
    ddr_cfg_path = config_values['ddr_cfg_path']
    ddr_cfg = config_values['ddr_cfg']
    ddr_type = config_values['ddr_type']


    # Clean up the target directory if it exists
    if os.path.exists(target_dir):
        shutil.rmtree(target_dir)
    os.makedirs(target_dir)

    # Copy configs
    source_dir = "configs"
    source_folder_path = os.path.join(source_path, source_dir, platform_name)
    destination_folder_path = os.path.join(source_path, target_dir, source_dir, platform_name)
    if not copy_folder(source_folder_path, destination_folder_path, [board_cfg]):
        print("Failed to copy: {}".format(source_folder_path))

    target_board_file = os.path.join(source_path, target_dir, source_dir, platform_name, board_cfg)

    configs_source_path = os.path.join(source_path, source_dir)
    destination_folder_path = os.path.join(source_path, target_dir, source_dir)
    copy_cfg_files(configs_source_path, destination_folder_path)


    # Copy firmwares
    source_dir = "firmwares"
    source_folder_path = os.path.join(source_path, source_dir, platform_name)
    destination_folder_path = os.path.join(source_path, target_dir, source_dir, platform_name)
    if not copy_folder(source_folder_path, destination_folder_path):
        print("Failed to copy: {}".format(source_folder_path))

    # Copy ddrs
    source_dir = "ddrs"
    source_folder_path = os.path.join(source_path, source_dir, ddr_type)
    destination_folder_path = os.path.join(source_path, target_dir, source_dir, ddr_type)
    if not copy_folder(source_folder_path, destination_folder_path, [ddr_cfg]):
        print("Failed to copy: {}".format(source_folder_path))

    configs_source_path = os.path.join(source_path, source_dir)
    destination_folder_path = os.path.join(source_path, target_dir, source_dir)
    copy_cfg_files(configs_source_path, destination_folder_path)


    copy_images(source_path, target_dir, board_cfg_path, target_board_file)

    copy_exec_files(source_path, target_dir)


    print("Extract completed.")
    print("Configuration extraction to factorytool has been completed!")


def copy_exec_files(source_dir, target_dir):
    """
    Copy specific files from source directory to target directory.

    :param source_dir: The source directory containing the files to be copied.
    :param target_dir: The target directory where files will be copied to.
    """

    files_to_copy = [
        os.path.join(source_dir, 'core.exe'),
        os.path.join(source_dir, 'bin', '32bit', 'core_32'),
        os.path.join(source_dir, 'bin', '64bit', 'core_64'),
        os.path.join(source_dir, 'USBClonerFactoryTool_64'),
        os.path.join(source_dir, 'USBClonerFactoryTool_32'),
        os.path.join(source_dir, 'qm_cn.qm')
    ]

    for src_file in files_to_copy:
        if os.path.exists(src_file):
            relative_path = os.path.relpath(src_file, source_dir)
            dst_file = os.path.join(target_dir, relative_path)
            dst_dir = os.path.dirname(dst_file)
            if not os.path.exists(dst_dir):
                os.makedirs(dst_dir)
            try:
                shutil.copy2(src_file, dst_file)
                print("File copied successfully: {} -> {}".format(src_file, dst_file))
            except Exception as e:
                print("Failed to copy file: {}".format(e))
        else:
            print("Source file does not exist: {}".format(src_file))


def copy_images(source_path, target_dir, board_cfg_path, target_board_file):
    """
    Process policies and copy files based on the policy's attribute if policy is enabled.

    :param source_path: Path to the source directory containing all necessary files and configs.
    :param target_dir: Target directory where configurations will be extracted.
    :param board_cfg_path: Path to the board configuration file.
    """
    images_dir = os.path.join(target_dir, "images")
    if not os.path.exists(images_dir):
        os.makedirs(images_dir)


    policy_count = get_config_value_from_file(board_cfg_path, 'policy', 'policy_count')

    for i in range(int(policy_count)):
        policy_enabled = get_config_value_from_file(board_cfg_path, 'policy{}'.format(i), 'enabled') == '1'
        if not policy_enabled:
            continue

        file_path = get_config_value_from_file(board_cfg_path, 'policy{}'.format(i), 'attribute')
        if not file_path or not os.path.exists(file_path):
            print("File does not exist: {}".format(file_path))
            continue

        file_name = os.path.basename(file_path)
        destination_file_path = os.path.join(images_dir, file_name)

        if not copy_file(file_path, destination_file_path):
            print("Failed to copy file to: {}".format(destination_file_path))
            continue


        set_config_value_to_file(target_board_file, 'policy{}'.format(i), 'attribute', './images/{}'.format(file_name))




def copy_cfg_files(src_dir, dst_dir):
    """
    Copy all .cfg files from src_dir to dst_dir, excluding subdirectories.

    :param src_dir: Source directory containing .cfg files.
    :param dst_dir: Target directory where .cfg files will be copied to.
    """
    if not os.path.exists(dst_dir):
        os.makedirs(dst_dir)

    for item in os.listdir(src_dir):
        s = os.path.join(src_dir, item)
        # Check if the item is a file and ends with .cfg
        if os.path.isfile(s) and item.endswith('.cfg'):
            d = os.path.join(dst_dir, item)
            try:
                shutil.copy2(s, d)  # copy2 preserves metadata
                print("File copied successfully: {} -> {}".format(s, d))
            except Exception as e:
                print("Failed to copy file: {}".format(e))

def copy_file(src, dst):
    """Copy a file from src to dst."""
    try:
        if os.path.exists(dst):
            os.remove(dst)
        shutil.copy(src, dst)
        print("File copied successfully: {} -> {}".format(src, dst))
    except Exception as e:
        print("Failed to copy file: {}".format(e))
        return False
    return True

def copy_folder(src, dst, name_filters=None):
    """Recursively copy a folder from src to dst."""
    if not os.path.exists(src):
        print("Source directory does not exist: {}".format(src))
        return False

    if not os.path.exists(dst):
        os.makedirs(dst)

    for item in os.listdir(src):
        s = os.path.join(src, item)
        d = os.path.join(dst, item)

	# Apply name filters if provided
        if name_filters and not any(fnmatch.fnmatch(item, pattern) for pattern in name_filters):
            continue

        if os.path.isdir(s):
            if not copy_folder(s, d, name_filters):
                return False
        else:
            if not copy_file(s, d):
                return False
    return True

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Extract configurations to a target directory.")
    parser.add_argument('source_path', type=str, help='Path to the source directory containing configuration files.')
    parser.add_argument('target_dir', type=str, help='Target directory where configurations will be extracted.')

    args = parser.parse_args()

    extract_config_to_factorytool(args.source_path, args.target_dir)
