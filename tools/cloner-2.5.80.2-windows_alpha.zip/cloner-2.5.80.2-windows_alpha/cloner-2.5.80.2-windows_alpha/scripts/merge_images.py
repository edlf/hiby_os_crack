#!/usr/bin/env python2
# -*- coding: utf-8 -*-

import json
import sys
import os

def read_partition_info(json_file):
    """Read partition information from JSON file."""
    with open(json_file, 'r') as f:
        partitions = json.load(f)['partitions']['tables']
    return {p['name']: {'offset': p['offset'], 'size': p['size']} for p in partitions}

def write_to_merged_image(merged_image_path, offset, input_file_path):
    """Write the content of input_file into merged_image at specified offset."""
    # Ensure the merged image is large enough
    file_size = os.path.getsize(input_file_path)
    if not os.path.exists(merged_image_path):
        with open(merged_image_path, 'wb') as f:
            f.seek(0)
            f.write(b'\x00' * (offset + file_size))

    with open(input_file_path, 'rb') as infile:
        data = infile.read()
        with open(merged_image_path, 'r+b') as outfile:
            outfile.seek(offset)
            outfile.write(data)

def main():
    if len(sys.argv) < 5:
        print("Usage: merge_images.py <merged_image.bin> <partition.json> [name@file.bin]+")
        return

    merged_image = sys.argv[1]
    partition_json = sys.argv[2]

    partitions = read_partition_info(partition_json)

    for arg in sys.argv[3:]:
        name, filepath = arg.split('@')
        if name in partitions:
            offset = int(partitions[name]['offset'], 16)
            write_to_merged_image(merged_image, offset, filepath)
        else:
            print("Partition {} not found in {}".format(name, partition_json))

if __name__ == '__main__':
    main()
